export const menuData = [
  {
    id: 1,
    label: "Home",
    href: "/",
  },
  {
    id: 2,
    label: "Umrah",
    href: "/tour?Umrahtype=Umrah",
  },
  {
    id: 3,
    label: "Hajj",
    href: "/tour?Hajjtype=Hajj",
  },
  {
    id: 4,
    label: "Culture Trip",
    href: "/tour?Culturetype=Culture+Trip",
  },
  {
    id: 4,
    label: "Blog",
    href: "/blogs",
  },
  {
    id: 5,
    label: "Contact",
    href: "contact",
  },
];
