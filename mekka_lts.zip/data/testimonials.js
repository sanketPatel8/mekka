export const testimonialsOne = [
  {
    id: 1,
    imageSrc: "/img/404/user.jpg",
    title: "5 stars",
    content:
      "Die Organisation und Planung war flexibel und an die Gruppe angepasst, was ein Riesen plus von meiner Sicht aus ist. Der Gruppenleiter war sehr gebildet und professionell. Ich konnte viel Neues lernen und für mein Leben eine Menge mitnehmen. Mal abgesehen vom Preis Leistung Verhältnis, wo keine andere Organisation mit halten kann, kann ich die Umrah mit sheikh Yassin herzlichst und sehr gutem Gewissen weiter empfehlen.",
    authorName: "Chahid Mouhinou",
    autorRole: "5 stars",
  },
  {
    id: 2,
    imageSrc: "/img/404/user.jpg",
    title: "5 stars",
    content:
      "Als erstes vielen Dank für das schönste Erlebnis. Von Anfang bis Ende war es einfach perfekt. Die Yasmin, die für das Visum gesorgt hat, hat einfach klasse Arbeit geleistet. Schnell und reibungslos. Der Reiseführer Khattab war ein sehr sympathischer und kompetenter Reiseführer. Wie er etwas erzählt hat war richtig gut und man hat ihn gerne zugehört. Er hat sich auch für alles verantwortlich gefühlt. Einfach ein tolles Team. Auf jeden Fall welter zu empfehlen! Danke",
    authorName: "Ali Shams",
    authorRole: "Explorer",
  },
  {
    id: 3,
    imageSrc: "/img/404/user.jpg",
    title: "5 stars",
    content:
      "Salam, bin sehr dankbar das es diese Seite gebt. Habe dadurch die Reise von mir und meine Familie perfekt planen können und die Leute bei Mekkabooking sind seriös und vertrauensvoll: alles war perfekt von Anfang bis Ende. Danke auch an Yasim",
    authorName: "Munim Oualali",
    authorRole: "Adventurer",
  },
  {
    id: 4,
    imageSrc: "/img/404/user.jpg",
    title: "5 stars",
    content:
      "Ich habe meine Umra mit dem Veranstalter gemacht. Alles war super. Khattab ist ein super Reiseführer. Dankeschön für alles.",
    authorName: "Aseel M",
    authorRole: "Adventurer",
  },
  {
    id: 5,
    imageSrc: "/img/404/user.jpg",
    title: "5 stars",
    content:
      "Sehr freundlich",
    authorName: "Ahmed Alamoudi",
    authorRole: "Adventurer",
  },
];

