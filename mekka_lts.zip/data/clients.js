export const clients = [
  "/img/clients/1/1.svg",
  "/img/clients/1/2.svg",
  // "/img/clients/1/3.svg",
  "/img/clients/1/4.svg",
  "/img/clients/1/5.svg",
  "/img/clients/1/6.svg",
  "/img/clients/1/1.svg",
  "/img/clients/1/2.svg",
  // "/img/clients/1/3.svg",
  "/img/clients/1/4.svg",
  "/img/clients/1/5.svg",
  "/img/clients/1/6.svg",
];

export const clients2 = [
  "/img/clients/2/1.svg",
  "/img/clients/2/2.svg",
  "/img/clients/2/3.svg",
  "/img/clients/2/4.svg",
  "/img/clients/2/5.svg",
  "/img/clients/2/6.svg",
  "/img/clients/2/1.svg",
  "/img/clients/2/2.svg",
  "/img/clients/2/3.svg",
  "/img/clients/2/4.svg",
  "/img/clients/2/5.svg",
  "/img/clients/2/6.svg",
];
