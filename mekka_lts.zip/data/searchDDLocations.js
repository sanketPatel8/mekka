export const locations = [
  { id: 1, choice: "All", type: "" },
  { id: 2, choice: "Hajj", type: "" },
  { id: 3, choice: "Umrah", type: "" },
  { id: 3, choice: "Cultural Trips", type: "" },

  
];
