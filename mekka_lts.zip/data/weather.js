export const weatherData = [
  { id: 1, period: "DEC - FEB", high: "7°", low: "3°" },
  { id: 2, period: "MAR - MAY", high: "17°", low: "3°" },
  { id: 3, period: "JUN - AUG", high: "27°", low: "3°" },
  { id: 4, period: "SEP - NOV", high: "7°", low: "3°" },
];
