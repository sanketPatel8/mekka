export const specialOffers = [
  {
    id: 1,
    subtitle: "Enjoy Upto",
    title: "60 % OFF",
    text: "on Your Booking",
    imgSrc: "/img/cta/10/1.jpg",
  },
  {
    id: 2,
    subtitle: "80% Discount",
    title: "Are You Ready To Turkey Tour",
    imgSrc: "/img/cta/10/2.jpg",
  },
  {
    id: 3,
    title: "Discover the wow of europe",
    imgSrc: "/img/cta/10/3.jpg",
  },
];
