import React from "react";
import Firstpage from "./home/page";

export default function page() {
  return (
    <>
      <Firstpage />
    </>
  );
}
